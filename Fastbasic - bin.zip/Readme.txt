FASTBASIC 2.0
By Paul Guerra


Notice: FastBasic is free to use, but if you want to use all or ANY part of it in your own programs and/or languages, you MUST ask me. Otherwise you would be violating the copyright.




What is FastBasic?
������������������
FastBasic is a programming language made in Visual Basic 6. It is NOT a scripting language: FastBasic compiles to a p-code that is executed by a runtime (or Virtual Machine, whatever you prefer).
Like older versions, FastBasic supports if's, do's, etc. This version also supports structures and arrays. Arrays can be static (fixed in size) or dynamic (no fixed size). Structures can be quite complex. For example, a structure can contain another structure, which contains a dynamic array of another structure, and so on.




About the runtime
�����������������
This version of FastBasic includes a C++ runtime. It is not a full implementation of the language, but soon it will be completed. This version of the runtime does NOT require any special .dll to run.
In spite of this it is still recommended to use the VB runtime, since it is more stable and supports the whole language.
In the editor you can choose which runtime to use to compile the program. Note that the compiler only uses this information to select the runtime file. The compiled program structure and the opcodes used are the same, i.e. the compiler generates EXACTLY THE SAME p-code for both runtimes.




What's new?
�����������

5/6/2003 (2.00.0146)

FIXED:

* Parameters were passed incorrectly.
* 'Select' block didn't work in some cases.

ADDED:

* More intrinsic functions (Rnd, RndInt, InStr and Int)
* 'Variant' data type added.

IMPROVED:

* Expanded the internal runtime stack from 10 to 200 (affects only C++ version).






If you have questions and/or suggestions, just drop me an e-mail at: pguerra_ar@yahoo.com




This program is provided "as is" without any kind of warranty. I am not responsible of the changes this program could eventually make to your system.

Copyright � 2003 Paul Guerra. All rights reserved.
